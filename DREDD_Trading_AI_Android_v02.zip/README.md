# DREDD Trading AI Android v0.2 — Exness / Forex + Gold

## Included
- Native Kotlin + Jetpack Compose Android app.
- Signal rule engine (EMA 20/50, RSI 14, ATR 14) using closed OHLC candles.
- Trade idea model with entry, ATR stop, ATR target, rationale and non-probabilistic rule score.
- Manual approval/rejection queue. Approval is recorded as DEMO QUEUE ONLY.
- Risk-budget calculator.
- Exness MT5 integration setup explanation.
- Safe MQL5 Expert Advisor scaffold that deliberately places no orders.

## Build
Open this project in Android Studio, sync Gradle, connect an Android device with USB debugging, and Run.
Build > Build Bundle(s) / APK(s) > Build APK(s) creates an APK.

## Critical execution architecture
The Android MT5 app does not run MQL5 Expert Advisors. For automated Exness MT5 execution, an Expert Advisor must run in MT5 desktop on a computer or Windows VPS. The Android app can be the approval/control client. A secure backend is required between Android and the EA.

## Not yet implemented
- Live prices / broker candle feed.
- Backend authentication and HTTPS API.
- Push notifications.
- Persistent Room database.
- MQL5 HTTP polling and actual order placement.
- Broker-derived lot sizing, tick-value conversion, margin checks.
- Backtesting and validated out-of-sample performance.
- Live order execution.

## Safety
No 90-100% accuracy claim is made. The displayed rule score is not probability. Do not use for live trades. Do not turn off demo mode expecting execution; no execution path exists in this build.
