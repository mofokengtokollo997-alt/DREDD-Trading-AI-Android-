// DREDD Trading AI - MT5 bridge scaffold
// Install in MT5 desktop: File > Open Data Folder > MQL5 > Experts.
// This scaffold deliberately DOES NOT place orders.
// Implement authenticated backend polling + explicit server-side approval before enabling execution.

#property strict
#property version "0.1"
#property description "DREDD bridge scaffold - safe no-trade mode"

input bool AllowOrderExecution = false;

int OnInit()
{
   Print("DREDD bridge loaded. Order execution is disabled by design.");
   if(AllowOrderExecution)
      Print("WARNING: This scaffold still contains no order execution implementation.");
   return(INIT_SUCCEEDED);
}

void OnTick()
{
   // Future: poll a trusted HTTPS backend on a timer, validate signed approved order intent,
   // enforce symbol/volume/SL/TP/daily-loss limits, then route to CTrade.
   // Do not accept arbitrary unauthenticated commands from a phone or public endpoint.
}
