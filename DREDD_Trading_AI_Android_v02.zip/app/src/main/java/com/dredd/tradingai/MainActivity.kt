package com.dredd.tradingai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max

private val Bg = Color(0xFF0B1018)
private val Panel = Color(0xFF151E2B)
private val Accent = Color(0xFF54D6A0)
private val Muted = Color(0xFF9AA8B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DreddApp() }
    }
}

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double)
data class TradeIdea(
    val id: String, val symbol: String, val timeframe: String, val side: String,
    val entry: Double, val stopLoss: Double, val takeProfit: Double,
    val riskReward: Double, val confidenceScore: Int, val rationale: String,
    val status: String = "PENDING"
)

object StrategyEngine {
    // This is a transparent rule-based demonstration, NOT a probability of profit.
    fun analyse(symbol: String, timeframe: String, candles: List<Candle>): TradeIdea? {
        if (candles.size < 60) return null
        val closes = candles.map { it.close }
        val fast = ema(closes, 20) ?: return null
        val slow = ema(closes, 50) ?: return null
        val rsi = rsi(closes, 14) ?: return null
        val atr = atr(candles, 14) ?: return null
        val last = candles.last()
        if (atr <= 0.0) return null

        val bullish = fast > slow && last.close > fast && rsi in 52.0..68.0
        val bearish = fast < slow && last.close < fast && rsi in 32.0..48.0
        if (!bullish && !bearish) return null

        val side = if (bullish) "BUY" else "SELL"
        val entry = last.close
        val sl = if (bullish) entry - 1.5 * atr else entry + 1.5 * atr
        val tp = if (bullish) entry + 3.0 * atr else entry - 3.0 * atr
        val score = (60 + (abs(fast - slow) / atr * 10).toInt()).coerceIn(60, 85)
        return TradeIdea(
            id = "$symbol-${last.time}",
            symbol = symbol, timeframe = timeframe, side = side,
            entry = entry, stopLoss = sl, takeProfit = tp,
            riskReward = 2.0, confidenceScore = score,
            rationale = "EMA20/EMA50 trend alignment; RSI=${
                "%.1f".format(rsi)
            }; ATR-based 1.5R stop and 3R target. Score is a rule score, not win probability."
        )
    }

    private fun ema(v: List<Double>, p: Int): Double? {
        if (v.size < p) return null
        val k = 2.0 / (p + 1)
        var e = v.take(p).average()
        v.drop(p).forEach { e = it * k + e * (1 - k) }
        return e
    }
    private fun rsi(v: List<Double>, p: Int): Double? {
        if (v.size <= p) return null
        val d = v.zipWithNext { a, b -> b - a }
        var g = d.take(p).filter { it > 0 }.sum() / p
        var l = -d.take(p).filter { it < 0 }.sum() / p
        for (x in d.drop(p)) {
            g = (g * (p - 1) + max(x, 0.0)) / p
            l = (l * (p - 1) + max(-x, 0.0)) / p
        }
        return if (l == 0.0) 100.0 else 100.0 - 100.0 / (1 + g / l)
    }
    private fun atr(c: List<Candle>, p: Int): Double? {
        if (c.size <= p) return null
        val tr = c.zipWithNext { prev, cur ->
            max(cur.high - cur.low, max(abs(cur.high - prev.close), abs(cur.low - prev.close)))
        }
        return tr.takeLast(p).average()
    }
}

class ApprovalBook {
    private val _ideas = mutableStateListOf<TradeIdea>()
    val ideas: List<TradeIdea> get() = _ideas
    fun add(idea: TradeIdea) {
        if (_ideas.none { it.id == idea.id }) _ideas.add(0, idea)
    }
    fun approve(id: String) {
        val i = _ideas.indexOfFirst { it.id == id }
        if (i >= 0 && _ideas[i].status == "PENDING") _ideas[i] = _ideas[i].copy(status = "APPROVED — DEMO QUEUE ONLY")
    }
    fun reject(id: String) {
        val i = _ideas.indexOfFirst { it.id == id }
        if (i >= 0 && _ideas[i].status == "PENDING") _ideas[i] = _ideas[i].copy(status = "REJECTED")
    }
}

@Composable
fun DreddApp() {
    val book = remember { ApprovalBook() }
    var screen by remember { mutableStateOf("Signals") }
    var demoOnly by remember { mutableStateOf(true) }
    var riskPercent by remember { mutableFloatStateOf(0.5f) }
    var accountBalance by remember { mutableStateOf("10000") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Signals", "Approvals", "Risk", "Setup").forEach { s ->
                    NavigationBarItem(selected = screen == s, onClick = { screen = s },
                        icon = { Text(when(s) { "Signals" -> "⌁"; "Approvals" -> "✓"; "Risk" -> "◎"; else -> "⚙" }) },
                        label = { Text(s) })
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
                Text("DREDD", color = Accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text("TRADING AI", fontWeight = FontWeight.ExtraBold, fontSize = 25.sp)
                Text("Exness MT5 • Forex + Gold • Manual approval", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(14.dp))
                when(screen) {
                    "Signals" -> SignalsScreen(book)
                    "Approvals" -> ApprovalScreen(book)
                    "Risk" -> RiskScreen(accountBalance, { accountBalance = it }, riskPercent, { riskPercent = it })
                    else -> SetupScreen(demoOnly, { demoOnly = it })
                }
            }
        }
    }
}

@Composable
fun SignalsScreen(book: ApprovalBook) {
    Text("Signal engine", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text("LIVE DATA NOT CONNECTED", color = Color(0xFFFFC66D), fontWeight = FontWeight.Bold)
            Text("The strategy engine is implemented, but it will not invent prices or create signals without verified OHLC candles.", color = Muted, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Supported initial instruments", fontWeight = FontWeight.Bold)
    listOf("XAUUSD / XAUUSDm (confirm broker suffix)", "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD").forEach {
        Text("• $it", color = Muted, fontSize = 13.sp)
    }
    Spacer(Modifier.height(12.dp))
    Text("Strategy: EMA20/50 trend + RSI(14) filter + ATR stop/target.", color = Accent, fontSize = 12.sp)
    Text("A score is not a calibrated probability. Backtest and forward-test before use.", color = Muted, fontSize = 11.sp)
}

@Composable
fun ApprovalScreen(book: ApprovalBook) {
    Text("Manual approval queue", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text("Approval currently records a demo decision only; no order is transmitted.", color = Muted, fontSize = 11.sp)
    Spacer(Modifier.height(10.dp))
    if (book.ideas.isEmpty()) {
        Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
            Text("No trade ideas yet. Connect a verified candle feed to generate candidate setups.", Modifier.padding(16.dp), color = Muted)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(book.ideas) { idea ->
                Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${idea.symbol} • ${idea.timeframe} • ${idea.side}", fontWeight = FontWeight.Bold)
                        Text("Entry ${idea.entry} | SL ${idea.stopLoss} | TP ${idea.takeProfit}", color = Muted, fontSize = 11.sp)
                        Text("Rule score ${idea.confidenceScore}/100 • RR ${idea.riskReward}", color = Accent, fontSize = 12.sp)
                        Text(idea.rationale, color = Muted, fontSize = 11.sp)
                        Text(idea.status, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        if (idea.status == "PENDING") {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { book.approve(idea.id) }) { Text("Approve demo") }
                                OutlinedButton(onClick = { book.reject(idea.id) }) { Text("Reject") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RiskScreen(balance: String, onBalance: (String) -> Unit, risk: Float, onRisk: (Float) -> Unit) {
    Text("Risk controls", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    OutlinedTextField(value = balance, onValueChange = onBalance, label = { Text("Account equity (account currency)") }, singleLine = true)
    Spacer(Modifier.height(12.dp))
    Text("Risk per trade: ${"%.2f".format(risk)}%")
    Slider(value = risk, onValueChange = onRisk, valueRange = 0.25f..2f)
    val loss = (balance.toDoubleOrNull() ?: 0.0) * risk / 100.0
    Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Maximum planned loss", color = Muted)
            Text("%.2f".format(loss), fontSize = 26.sp, color = Accent, fontWeight = FontWeight.Bold)
            Text("This is a cash-risk budget, not a lot-size calculation. Lot size needs symbol tick value, tick size, contract size and stop distance from the broker.", color = Muted, fontSize = 11.sp)
        }
    }
    Spacer(Modifier.height(10.dp))
    Text("Hard controls required before execution:", fontWeight = FontWeight.Bold)
    Text("• Max daily loss and max open positions\n• Reject stale or incomplete candles\n• Validate spread and trading session\n• Reject invalid volume / stop distances\n• Never increase risk after a loss", color = Muted, fontSize = 12.sp)
}

@Composable
fun SetupScreen(demoOnly: Boolean, onDemo: (Boolean) -> Unit) {
    Text("Execution setup", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text("Broker: Exness via MetaTrader 5", fontWeight = FontWeight.Bold)
            Text("The Android app cannot run an MT5 Expert Advisor itself. Automated MT5 execution requires the EA to run in desktop MT5 or on a Windows VPS. Android is the control/approval interface.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Demo-only mode", Modifier.weight(1f))
                Switch(checked = demoOnly, onCheckedChange = onDemo)
            }
            Text(if (demoOnly) "ON — live execution is disabled." else "OFF — this UI switch does not enable live trading. Server-side safeguards and broker bridge are not implemented.", color = if (demoOnly) Accent else Color(0xFFFFC66D), fontSize = 11.sp)
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Next integration components", fontWeight = FontWeight.Bold)
    Text("1. MT5 Expert Advisor bridge (MQL5)\n2. Authenticated HTTPS backend\n3. Candle feed + symbol mapping\n4. Push approval notification\n5. Server-side order validation and audit log", color = Muted, fontSize = 12.sp)
}
